#include "wa/signal.hpp"

#include <openssl/crypto.h>
#include <sys/stat.h>

#include <algorithm>
#include <cstdio>
#include <fstream>
#include <sstream>

namespace wa::sig {
namespace {

constexpr std::size_t kMaxSkip = 2000;
constexpr std::size_t kMaxSkippedStored = 2000;
constexpr std::size_t kMaxSessions = 20;
constexpr std::size_t kMaxReceiveChains = 5;
constexpr std::uint32_t kMaxPreKeyId = 0xFFFFFF;

Bytes be(std::uint32_t value, int width) {
    Bytes out(static_cast<std::size_t>(width));
    for (int i = 0; i < width; ++i)
        out[static_cast<std::size_t>(width - 1 - i)] = static_cast<std::uint8_t>(value >> (8 * i));
    return out;
}

Bytes prefixed(ByteView raw) {
    Bytes out;
    out.reserve(raw.size() + 1);
    out.push_back(0x05);
    out.insert(out.end(), raw.begin(), raw.end());
    return out;
}

Result<Bytes> unprefixed(ByteView key) {
    if (key.size() == 33 && key[0] == 0x05) return Bytes(key.begin() + 1, key.end());
    if (key.size() == 32) return Bytes(key.begin(), key.end());
    return fail("kunci publik Signal tidak valid", ErrorCode::protocol);
}

Bytes slice(const Bytes& b, std::size_t off, std::size_t n) {
    return Bytes(b.begin() + static_cast<std::ptrdiff_t>(off), b.begin() + static_cast<std::ptrdiff_t>(off + n));
}

Bytes kdf(ByteView input, ByteView salt, std::string_view info, std::size_t length) {
    return crypto::hkdf_sha256(input, length, salt, view_of(info));
}

Bytes hmac_byte(ByteView key, std::uint8_t value) { return crypto::hmac_sha256(key, ByteView(&value, 1)); }

// ------------------------------------------------------------ serialisasi ---

Bytes serialize_chain(const Chain& c) {
    pb::Writer w;
    w.bytes(1, c.ratchet_key)
        .bytes(2, c.chain_key)
        .varint(3, static_cast<std::uint64_t>(c.index + 1))
        .varint(4, c.sending ? 1 : 0);
    for (const auto& k : c.skipped) {
        pb::Writer sk;
        sk.varint(1, k.counter).bytes(2, k.seed);
        w.message(5, sk);
    }
    return w.take();
}

Bytes serialize_session(const Session& s) {
    pb::Writer w;
    w.bytes(1, s.remote_identity)
        .bytes(2, s.base_key)
        .bytes(3, s.root_key)
        .bytes(4, s.our_ratchet.priv)
        .bytes(5, s.our_ratchet.pub)
        .bytes(6, s.last_remote_ratchet)
        .varint(7, s.previous_counter)
        .varint(8, s.registration_id)
        .varint(10, s.open ? 1 : 0);
    if (s.pending.active) {
        w.varint(11, 1)
            .varint(12, s.pending.signed_id)
            .varint(13, s.pending.has_prekey ? 1 : 0)
            .varint(14, s.pending.prekey_id)
            .bytes(15, s.pending.base_key);
    }
    for (const auto& c : s.chains) w.bytes(9, serialize_chain(c));
    return w.take();
}

Bytes serialize_sessions(const std::vector<Session>& list) {
    pb::Writer w;
    for (const auto& s : list) w.bytes(1, serialize_session(s));
    return w.take();
}

Result<Chain> parse_chain(ByteView data) {
    Chain c;
    pb::Reader r(data);
    for (;;) {
        auto f = r.next();
        if (!f) return std::unexpected(f.error());
        if (!*f) break;
        const auto& fd = **f;
        switch (fd.number) {
            case 1: c.ratchet_key.assign(fd.data.begin(), fd.data.end()); break;
            case 2: c.chain_key.assign(fd.data.begin(), fd.data.end()); break;
            case 3: c.index = static_cast<std::int64_t>(fd.value) - 1; break;
            case 4: c.sending = fd.value != 0; break;
            case 5: {
                SkippedKey k;
                pb::Reader kr(fd.data);
                for (;;) {
                    auto kf = kr.next();
                    if (!kf) return std::unexpected(kf.error());
                    if (!*kf) break;
                    const auto& kd = **kf;
                    if (kd.number == 1) k.counter = static_cast<std::uint32_t>(kd.value);
                    else if (kd.number == 2) k.seed.assign(kd.data.begin(), kd.data.end());
                }
                c.skipped.push_back(std::move(k));
                break;
            }
            default: break;
        }
    }
    return c;
}

Result<Session> parse_session(ByteView data) {
    Session s;
    pb::Reader r(data);
    for (;;) {
        auto f = r.next();
        if (!f) return std::unexpected(f.error());
        if (!*f) break;
        const auto& fd = **f;
        switch (fd.number) {
            case 1: s.remote_identity.assign(fd.data.begin(), fd.data.end()); break;
            case 2: s.base_key.assign(fd.data.begin(), fd.data.end()); break;
            case 3: s.root_key.assign(fd.data.begin(), fd.data.end()); break;
            case 4: s.our_ratchet.priv.assign(fd.data.begin(), fd.data.end()); break;
            case 5: s.our_ratchet.pub.assign(fd.data.begin(), fd.data.end()); break;
            case 6: s.last_remote_ratchet.assign(fd.data.begin(), fd.data.end()); break;
            case 7: s.previous_counter = static_cast<std::uint32_t>(fd.value); break;
            case 8: s.registration_id = static_cast<std::uint32_t>(fd.value); break;
            case 9: {
                auto c = parse_chain(fd.data);
                if (!c) return std::unexpected(c.error());
                s.chains.push_back(std::move(*c));
                break;
            }
            case 10: s.open = fd.value != 0; break;
            case 11: s.pending.active = fd.value != 0; break;
            case 12: s.pending.signed_id = static_cast<std::uint32_t>(fd.value); break;
            case 13: s.pending.has_prekey = fd.value != 0; break;
            case 14: s.pending.prekey_id = static_cast<std::uint32_t>(fd.value); break;
            case 15: s.pending.base_key.assign(fd.data.begin(), fd.data.end()); break;
            default: break;
        }
    }
    return s;
}

Result<std::vector<Session>> parse_sessions(ByteView data) {
    std::vector<Session> out;
    pb::Reader r(data);
    for (;;) {
        auto f = r.next();
        if (!f) return std::unexpected(f.error());
        if (!*f) break;
        if ((*f)->number != 1 || (*f)->wire != 2) continue;
        auto s = parse_session((*f)->data);
        if (!s) return std::unexpected(s.error());
        out.push_back(std::move(*s));
    }
    return out;
}

// ----------------------------------------------------------- Double Ratchet ---

struct MessageKeys {
    Bytes cipher;
    Bytes mac;
    Bytes iv;
};

MessageKeys derive_message_keys(ByteView seed) {
    const Bytes okm = kdf(seed, Bytes(32, 0), "WhisperMessageKeys", 96);
    return MessageKeys{slice(okm, 0, 32), slice(okm, 32, 32), slice(okm, 64, 16)};
}

Chain* find_chain(Session& s, ByteView key) {
    for (auto& c : s.chains)
        if (std::ranges::equal(c.ratchet_key, key)) return &c;
    return nullptr;
}

// Maju satu langkah: kembalikan seed pesan, ganti chain_key.
Bytes step_chain(Chain& c) {
    Bytes seed = hmac_byte(c.chain_key, 0x01);
    c.chain_key = hmac_byte(c.chain_key, 0x02);
    c.index += 1;
    return seed;
}

Result<Bytes> take_message_seed(Chain& c, std::uint32_t counter) {
    for (auto it = c.skipped.begin(); it != c.skipped.end(); ++it) {
        if (it->counter == counter) {
            Bytes seed = std::move(it->seed);
            c.skipped.erase(it);
            return seed;
        }
    }
    const auto target = static_cast<std::int64_t>(counter);
    if (c.index >= target) return fail("pesan duplikat atau kunci sudah dipakai", ErrorCode::crypto);
    if (static_cast<std::size_t>(target - c.index) > kMaxSkip) return fail("loncatan counter terlalu jauh", ErrorCode::crypto);
    while (c.index < target) {
        Bytes seed = step_chain(c);
        if (c.index == target) return seed;
        c.skipped.push_back(SkippedKey{static_cast<std::uint32_t>(c.index), std::move(seed)});
        if (c.skipped.size() > kMaxSkippedStored) c.skipped.erase(c.skipped.begin());
    }
    return fail("gagal mengambil kunci pesan", ErrorCode::crypto);
}

// Ratchet DH sisi penerima: rantai penerima baru + pasangan ratchet & rantai pengirim baru.
Result<void> step_ratchet(Session& s, const Bytes& remote) {
    if (find_chain(s, remote)) return {};

    auto dh = crypto::x25519_shared(s.our_ratchet.priv, remote);
    if (!dh) return std::unexpected(dh.error());
    const Bytes okm = kdf(*dh, s.root_key, "WhisperRatchet", 64);
    const Bytes root1 = slice(okm, 0, 32);

    Chain recv;
    recv.ratchet_key = remote;
    recv.chain_key = slice(okm, 32, 32);
    recv.index = -1;
    recv.sending = false;

    auto fresh = crypto::x25519_generate();
    if (!fresh) return std::unexpected(fresh.error());
    auto dh2 = crypto::x25519_shared(fresh->priv, remote);
    if (!dh2) return std::unexpected(dh2.error());
    const Bytes okm2 = kdf(*dh2, root1, "WhisperRatchet", 64);

    for (const auto& c : s.chains)
        if (c.sending) s.previous_counter = static_cast<std::uint32_t>(std::max<std::int64_t>(c.index, 0));
    std::erase_if(s.chains, [](const Chain& c) { return c.sending; });
    s.chains.push_back(std::move(recv));

    Chain send;
    send.ratchet_key = fresh->pub;
    send.chain_key = slice(okm2, 32, 32);
    send.index = -1;
    send.sending = true;
    s.chains.push_back(std::move(send));

    std::size_t receiving = 0;
    for (const auto& c : s.chains)
        if (!c.sending) ++receiving;
    for (auto it = s.chains.begin(); receiving > kMaxReceiveChains && it != s.chains.end();) {
        if (!it->sending) {
            it = s.chains.erase(it);
            --receiving;
        } else {
            ++it;
        }
    }

    s.root_key = slice(okm2, 0, 32);
    s.our_ratchet = std::move(*fresh);
    s.last_remote_ratchet = remote;
    return {};
}

// X3DH sisi penerima. secret = 0xFF*32 || DH1 || DH2 || DH3 [|| DH4].
Result<Session> init_incoming(const Creds& creds, const PreKey* one_time, ByteView their_identity, ByteView base_key,
                              std::uint32_t registration_id) {
    auto dh1 = crypto::x25519_shared(creds.signed_prekey.priv, their_identity);
    auto dh2 = crypto::x25519_shared(creds.identity_key.priv, base_key);
    auto dh3 = crypto::x25519_shared(creds.signed_prekey.priv, base_key);
    if (!dh1) return std::unexpected(dh1.error());
    if (!dh2) return std::unexpected(dh2.error());
    if (!dh3) return std::unexpected(dh3.error());

    Bytes secret(32, 0xFF);
    secret.insert(secret.end(), dh1->begin(), dh1->end());
    secret.insert(secret.end(), dh2->begin(), dh2->end());
    secret.insert(secret.end(), dh3->begin(), dh3->end());
    if (one_time) {
        auto dh4 = crypto::x25519_shared(one_time->pair.priv, base_key);
        if (!dh4) return std::unexpected(dh4.error());
        secret.insert(secret.end(), dh4->begin(), dh4->end());
    }
    const Bytes okm = kdf(secret, Bytes(32, 0), "WhisperText", 64);

    Session s;
    s.remote_identity.assign(their_identity.begin(), their_identity.end());
    s.base_key.assign(base_key.begin(), base_key.end());
    s.root_key = slice(okm, 0, 32);
    s.our_ratchet = creds.signed_prekey;
    s.last_remote_ratchet = s.base_key;
    s.registration_id = registration_id;
    s.open = true;
    return s;
}

struct WhisperFields {
    Bytes ratchet_key;
    std::uint32_t counter{0};
    std::uint32_t previous{0};
    Bytes ciphertext;
};

Result<WhisperFields> parse_whisper(ByteView proto) {
    WhisperFields w;
    pb::Reader r(proto);
    for (;;) {
        auto f = r.next();
        if (!f) return std::unexpected(f.error());
        if (!*f) break;
        const auto& fd = **f;
        switch (fd.number) {
            case 1: w.ratchet_key.assign(fd.data.begin(), fd.data.end()); break;
            case 2: w.counter = static_cast<std::uint32_t>(fd.value); break;
            case 3: w.previous = static_cast<std::uint32_t>(fd.value); break;
            case 4: w.ciphertext.assign(fd.data.begin(), fd.data.end()); break;
            default: break;
        }
    }
    if (w.ratchet_key.empty() || w.ciphertext.empty()) return fail("SignalMessage tidak lengkap", ErrorCode::protocol);
    return w;
}

// Mengubah `session` hanya bila MAC cocok dan dekripsi berhasil.
Result<Bytes> decrypt_with_session(const Creds& creds, Session& session, ByteView message) {
    if (message.size() < 1 + 8 + 4) return fail("pesan Signal terlalu pendek", ErrorCode::protocol);
    if ((message[0] >> 4) < 3 || (message[0] & 0x0F) > 3)
        return fail("versi pesan Signal tidak didukung", ErrorCode::protocol);
    const ByteView proto = message.subspan(1, message.size() - 9);
    const ByteView mac = message.last(8);

    auto fields = parse_whisper(proto);
    if (!fields) return std::unexpected(fields.error());
    auto remote = unprefixed(fields->ratchet_key);
    if (!remote) return std::unexpected(remote.error());

    Session work = session;
    if (auto r = step_ratchet(work, *remote); !r) return std::unexpected(r.error());
    Chain* chain = find_chain(work, *remote);
    if (!chain || chain->sending) return fail("rantai penerima tidak ditemukan", ErrorCode::crypto);
    auto seed = take_message_seed(*chain, fields->counter);
    if (!seed) return std::unexpected(seed.error());
    const MessageKeys keys = derive_message_keys(*seed);

    // MAC = HMAC(mac_key, remoteIdentity(33) || ourIdentity(33) || versi || proto)[0..8]
    const Bytes mac_input =
        concat({prefixed(work.remote_identity), prefixed(creds.identity_key.pub), message.first(1), proto});
    const Bytes expected = crypto::hmac_sha256(keys.mac, mac_input);
    if (CRYPTO_memcmp(expected.data(), mac.data(), 8) != 0)
        return fail("MAC pesan Signal tidak cocok", ErrorCode::crypto);

    auto plain = crypto::aes256_cbc_decrypt(keys.cipher, keys.iv, fields->ciphertext);
    if (!plain) return plain;
    work.pending = PendingPreKey{};  // lawan bicara sudah membalas: pkmsg tidak diperlukan lagi
    session = std::move(work);
    return plain;
}

binary::Node prekey_node(const PreKey& k) {
    using namespace binary;
    return make_node("key", {},
                     NodeList{make_node("id", {}, be(k.id, 3)), make_node("value", {}, k.pair.pub)});
}

binary::Node signed_prekey_node(const Creds& c) {
    using namespace binary;
    return make_node("skey", {},
                     NodeList{make_node("id", {}, be(c.signed_prekey_id, 3)),
                              make_node("value", {}, c.signed_prekey.pub),
                              make_node("signature", {}, c.signed_prekey_sig)});
}

}  // namespace

// ------------------------------------------------------------------ Store ---

std::vector<PreKey> Store::generate_prekeys(std::size_t count) {
    std::vector<PreKey> out;
    for (std::size_t i = 0; i < count; ++i) {
        auto kp = crypto::x25519_generate();
        if (!kp) break;
        if (next_prekey_id_ == 0 || next_prekey_id_ > kMaxPreKeyId) next_prekey_id_ = 1;
        PreKey pk;
        pk.id = next_prekey_id_++;
        pk.pair = std::move(*kp);
        prekeys_[pk.id] = pk;
        out.push_back(std::move(pk));
    }
    return out;
}

const PreKey* Store::find_prekey(std::uint32_t id) const {
    const auto it = prekeys_.find(id);
    return it == prekeys_.end() ? nullptr : &it->second;
}

void Store::remove_prekey(std::uint32_t id) { prekeys_.erase(id); }

Result<void> Store::load() {
    std::ifstream f(path_, std::ios::binary);
    if (!f) return {};
    prekeys_.clear();
    sessions_.clear();
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty() || line[0] == '#') continue;
        std::istringstream ls(line);
        std::string tag;
        ls >> tag;
        if (tag == "N") {
            ls >> next_prekey_id_;
        } else if (tag == "P") {
            std::uint32_t id = 0;
            std::string priv;
            std::string pub;
            ls >> id >> priv >> pub;
            auto p = from_hex(priv);
            auto q = from_hex(pub);
            if (!p || !q || p->size() != 32 || q->size() != 32) return fail("store: prekey rusak");
            PreKey pk;
            pk.id = id;
            pk.pair.priv = std::move(*p);
            pk.pair.pub = std::move(*q);
            prekeys_[id] = std::move(pk);
        } else if (tag == "S") {
            std::string addr;
            std::string hexdata;
            ls >> addr >> hexdata;
            auto raw = from_hex(hexdata);
            if (!raw) return fail("store: sesi rusak (hex)");
            auto parsed = parse_sessions(*raw);
            if (!parsed) return std::unexpected(parsed.error());
            sessions_[addr] = std::move(*parsed);
        }
    }
    return {};
}

Result<void> Store::save() const {
    std::ostringstream o;
    o << "# wacpp signal store - rahasia, jangan dibagikan\n";
    o << "N " << next_prekey_id_ << '\n';
    for (const auto& [id, pk] : prekeys_) o << "P " << id << ' ' << to_hex(pk.pair.priv) << ' ' << to_hex(pk.pair.pub) << '\n';
    for (const auto& [addr, list] : sessions_)
        if (!list.empty()) o << "S " << addr << ' ' << to_hex(serialize_sessions(list)) << '\n';

    const std::string tmp = path_ + ".tmp";
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) return fail("store: tidak bisa menulis " + tmp, ErrorCode::io);
        f << o.str();
        if (!f.good()) return fail("store: gagal menulis " + tmp, ErrorCode::io);
    }
    ::chmod(tmp.c_str(), 0600);
    if (std::rename(tmp.c_str(), path_.c_str()) != 0) return fail("store: rename gagal", ErrorCode::io);
    return {};
}

// ----------------------------------------------------------------- Cipher ---

Result<Bytes> Cipher::decrypt(const std::string& address, std::string_view type, ByteView ciphertext) {
    if (type == "pkmsg") return decrypt_prekey(address, ciphertext);
    if (type == "msg") return decrypt_whisper(address, ciphertext);
    return fail("tipe enc tidak didukung: " + std::string(type), ErrorCode::protocol);
}

Result<Bytes> Cipher::decrypt_prekey(const std::string& address, ByteView message) {
    if (message.size() < 2 || (message[0] >> 4) < 3) return fail("versi pkmsg tidak didukung", ErrorCode::protocol);

    Bytes base_key_raw;
    Bytes identity_raw;
    Bytes inner;
    std::uint32_t registration_id = 0;
    std::uint32_t signed_prekey_id = 0;
    std::uint32_t prekey_id = 0;
    bool has_prekey = false;
    pb::Reader r(message.subspan(1));
    for (;;) {
        auto f = r.next();
        if (!f) return std::unexpected(f.error());
        if (!*f) break;
        const auto& fd = **f;
        switch (fd.number) {
            case 1: prekey_id = static_cast<std::uint32_t>(fd.value); has_prekey = true; break;
            case 2: base_key_raw.assign(fd.data.begin(), fd.data.end()); break;
            case 3: identity_raw.assign(fd.data.begin(), fd.data.end()); break;
            case 4: inner.assign(fd.data.begin(), fd.data.end()); break;
            case 5: registration_id = static_cast<std::uint32_t>(fd.value); break;
            case 6: signed_prekey_id = static_cast<std::uint32_t>(fd.value); break;
            default: break;
        }
    }
    auto base = unprefixed(base_key_raw);
    auto ident = unprefixed(identity_raw);
    if (!base || !ident || inner.empty()) return fail("pkmsg tidak lengkap", ErrorCode::protocol);

    std::vector<Session> work = store_.sessions(address);
    std::size_t idx = work.size();
    for (std::size_t i = 0; i < work.size(); ++i) {
        if (work[i].base_key == *base) {
            idx = i;
            break;
        }
    }
    bool created = false;
    if (idx == work.size()) {
        if (signed_prekey_id != creds_.signed_prekey_id)
            return fail(std::format("signed prekey id {} tidak dikenal", signed_prekey_id), ErrorCode::protocol);
        const PreKey* one_time = nullptr;
        if (has_prekey) {
            one_time = store_.find_prekey(prekey_id);
            if (!one_time) return fail(std::format("prekey {} tidak ditemukan", prekey_id), ErrorCode::protocol);
        }
        auto s = init_incoming(creds_, one_time, *ident, *base, registration_id);
        if (!s) return std::unexpected(s.error());
        for (auto& old : work) old.open = false;
        work.insert(work.begin(), std::move(*s));
        if (work.size() > kMaxSessions) work.pop_back();
        idx = 0;
        created = true;
    }

    auto plain = decrypt_with_session(creds_, work[idx], inner);
    if (!plain) return plain;
    store_.sessions(address) = std::move(work);
    if (created && has_prekey) store_.remove_prekey(prekey_id);
    return plain;
}

Result<Bytes> Cipher::decrypt_whisper(const std::string& address, ByteView message) {
    std::vector<Session> work = store_.sessions(address);
    if (work.empty()) return fail("tidak ada sesi Signal untuk " + address, ErrorCode::protocol);
    std::string last;
    for (auto& s : work) {
        auto plain = decrypt_with_session(creds_, s, message);
        if (plain) {
            store_.sessions(address) = std::move(work);
            return plain;
        }
        last = plain.error().message;
    }
    return fail("semua sesi gagal mendekripsi: " + last, ErrorCode::crypto);
}

// -------------------------------------------------------------- builder iq ---

binary::Node build_prekey_count_query(std::string_view iq_id) {
    using namespace binary;
    return make_node("iq",
                     {{"id", std::string(iq_id)}, {"xmlns", "encrypt"}, {"type", "get"}, {"to", "s.whatsapp.net"}},
                     NodeList{make_node("count")});
}

binary::Node build_prekey_upload(const Creds& c, const std::vector<PreKey>& keys, std::string_view iq_id) {
    using namespace binary;
    NodeList list;
    for (const auto& k : keys) list.push_back(prekey_node(k));
    NodeList content;
    content.push_back(make_node("registration", {}, be(c.registration_id, 4)));
    content.push_back(make_node("type", {}, Bytes{5}));
    content.push_back(make_node("identity", {}, c.identity_key.pub));
    content.push_back(make_node("list", {}, std::move(list)));
    content.push_back(signed_prekey_node(c));
    return make_node("iq",
                     {{"id", std::string(iq_id)}, {"xmlns", "encrypt"}, {"type", "set"}, {"to", "s.whatsapp.net"}},
                     std::move(content));
}

binary::Node build_retry_receipt(const Creds& c, const binary::Node& msg, int count, const PreKey* key) {
    using namespace binary;
    const std::string id(msg.attr("id").value_or(""));
    Attrs attrs{{"id", id}, {"type", "retry"}, {"to", std::string(msg.attr("from").value_or(""))}};
    if (const auto r = msg.attr("recipient")) attrs.emplace_back("recipient", std::string(*r));
    if (const auto p = msg.attr("participant")) attrs.emplace_back("participant", std::string(*p));

    NodeList content;
    content.push_back(make_node("retry", {{"count", std::to_string(count)},
                                          {"id", id},
                                          {"t", std::string(msg.attr("t").value_or("0"))},
                                          {"v", "1"},
                                          {"error", "0"}}));
    content.push_back(make_node("registration", {}, be(c.registration_id, 4)));
    if (key) {
        content.push_back(make_node("keys", {},
                                    NodeList{make_node("type", {}, Bytes{5}),
                                             make_node("identity", {}, c.identity_key.pub), prekey_node(*key),
                                             signed_prekey_node(c), make_node("device-identity", {}, c.account)}));
    }
    return make_node("receipt", std::move(attrs), std::move(content));
}

}  // namespace wa::sig
