#include "wa/ws.hpp"

#include <arpa/inet.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstring>
#include <mutex>

#include "wa/crypto.hpp"

namespace wa {
namespace {

using Clock = std::chrono::steady_clock;
constexpr std::size_t kMaxMessage = 64u * 1024u * 1024u;
constexpr std::string_view kWsGuid = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

struct WsUrl {
    bool tls{};
    std::string host;
    std::string port;
    std::string path;
};

Result<WsUrl> parse_url(std::string_view url) {
    WsUrl u;
    if (url.starts_with("wss://")) {
        u.tls = true;
        u.port = "443";
        url.remove_prefix(6);
    } else if (url.starts_with("ws://")) {
        u.tls = false;
        u.port = "80";
        url.remove_prefix(5);
    } else {
        return fail("URL harus diawali ws:// atau wss://");
    }
    const auto slash = url.find('/');
    const std::string_view hostport = url.substr(0, slash);
    u.path = slash == std::string_view::npos ? "/" : std::string(url.substr(slash));
    const auto colon = hostport.rfind(':');
    if (colon != std::string_view::npos) {
        u.host = std::string(hostport.substr(0, colon));
        u.port = std::string(hostport.substr(colon + 1));
    } else {
        u.host = std::string(hostport);
    }
    if (u.host.empty()) return fail("URL tanpa host");
    return u;
}

std::string ssl_error_string() {
    const unsigned long e = ERR_get_error();
    if (e == 0) return "tidak diketahui";
    char buf[256];
    ERR_error_string_n(e, buf, sizeof buf);
    return buf;
}

int elapsed_ms(Clock::time_point since) {
    return static_cast<int>(std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - since).count());
}

}  // namespace

struct WsClient::Impl {
    int fd{-1};
    SSL_CTX* ctx{nullptr};
    SSL* ssl{nullptr};
    std::atomic<bool> open{false};
    std::mutex write_mutex;
    Bytes rbuf;
    Bytes frag;
    WsOp frag_op{WsOp::binary};
    bool in_frag{false};

    ~Impl() { teardown(); }

    void teardown() {
        open = false;
        if (ssl) {
            SSL_shutdown(ssl);
            SSL_free(ssl);
            ssl = nullptr;
        }
        if (ctx) {
            SSL_CTX_free(ctx);
            ctx = nullptr;
        }
        if (fd >= 0) {
            ::close(fd);
            fd = -1;
        }
    }

    // Mengembalikan 0 byte bila perlu diulang (WANT_READ / EINTR).
    Result<std::size_t> read_some(void* buf, std::size_t n, int timeout_ms) {
        if (!(ssl && SSL_pending(ssl) > 0)) {
            pollfd p{fd, POLLIN, 0};
            int r;
            do {
                r = ::poll(&p, 1, timeout_ms);
            } while (r < 0 && errno == EINTR);
            if (r == 0) return fail("timeout menunggu data", ErrorCode::timeout);
            if (r < 0) return fail(std::string("poll: ") + std::strerror(errno), ErrorCode::io);
        }
        if (ssl) {
            const int r = SSL_read(ssl, buf, static_cast<int>(n));
            if (r > 0) return static_cast<std::size_t>(r);
            const int err = SSL_get_error(ssl, r);
            if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) return std::size_t{0};
            open = false;
            if (err == SSL_ERROR_ZERO_RETURN) return fail("koneksi ditutup server", ErrorCode::closed);
            return fail("SSL_read: " + ssl_error_string(), ErrorCode::io);
        }
        const ssize_t r = ::recv(fd, buf, n, 0);
        if (r > 0) return static_cast<std::size_t>(r);
        if (r < 0 && (errno == EINTR || errno == EAGAIN)) return std::size_t{0};
        open = false;
        if (r == 0) return fail("koneksi ditutup server", ErrorCode::closed);
        return fail(std::string("recv: ") + std::strerror(errno), ErrorCode::io);
    }

    Result<void> write_all(ByteView data) {
        std::size_t off = 0;
        while (off < data.size()) {
            const std::size_t chunk = data.size() - off;
            if (ssl) {
                const int r = SSL_write(ssl, data.data() + off, static_cast<int>(std::min<std::size_t>(chunk, 1 << 20)));
                if (r <= 0) {
                    open = false;
                    return fail("SSL_write: " + ssl_error_string(), ErrorCode::io);
                }
                off += static_cast<std::size_t>(r);
            } else {
                const ssize_t r = ::send(fd, data.data() + off, chunk, MSG_NOSIGNAL);
                if (r < 0 && errno == EINTR) continue;
                if (r <= 0) {
                    open = false;
                    return fail(std::string("send: ") + std::strerror(errno), ErrorCode::io);
                }
                off += static_cast<std::size_t>(r);
            }
        }
        return {};
    }

    Result<void> send_frame(std::uint8_t opcode, ByteView data) {
        if (!open) return fail("koneksi tidak terbuka", ErrorCode::closed);
        Bytes frame;
        frame.reserve(data.size() + 14);
        frame.push_back(static_cast<std::uint8_t>(0x80 | opcode));
        if (data.size() < 126) {
            frame.push_back(static_cast<std::uint8_t>(0x80 | data.size()));
        } else if (data.size() <= 0xFFFF) {
            frame.push_back(0x80 | 126);
            frame.push_back(static_cast<std::uint8_t>(data.size() >> 8));
            frame.push_back(static_cast<std::uint8_t>(data.size()));
        } else {
            frame.push_back(0x80 | 127);
            for (int i = 7; i >= 0; --i) frame.push_back(static_cast<std::uint8_t>(std::uint64_t(data.size()) >> (8 * i)));
        }
        const Bytes mask = crypto::random_bytes(4);
        frame.insert(frame.end(), mask.begin(), mask.end());
        for (std::size_t i = 0; i < data.size(); ++i) frame.push_back(data[i] ^ mask[i & 3]);
        std::lock_guard<std::mutex> lock(write_mutex);
        return write_all(frame);
    }

    // nullopt = belum ada pesan data lengkap di buffer.
    Result<std::optional<WsMessage>> try_parse() {
        for (;;) {
            if (rbuf.size() < 2) return std::optional<WsMessage>{};
            const std::uint8_t b0 = rbuf[0];
            const std::uint8_t b1 = rbuf[1];
            const bool fin = (b0 & 0x80) != 0;
            const std::uint8_t opcode = b0 & 0x0F;
            const bool masked = (b1 & 0x80) != 0;
            std::uint64_t len = b1 & 0x7F;
            std::size_t hdr = 2;
            if (len == 126) {
                if (rbuf.size() < 4) return std::optional<WsMessage>{};
                len = (std::uint64_t(rbuf[2]) << 8) | rbuf[3];
                hdr = 4;
            } else if (len == 127) {
                if (rbuf.size() < 10) return std::optional<WsMessage>{};
                len = 0;
                for (int i = 0; i < 8; ++i) len = (len << 8) | rbuf[2 + i];
                hdr = 10;
            }
            if (len > kMaxMessage) return fail("frame WebSocket terlalu besar", ErrorCode::protocol);
            const std::size_t mask_len = masked ? 4 : 0;
            const std::size_t total = hdr + mask_len + static_cast<std::size_t>(len);
            if (rbuf.size() < total) return std::optional<WsMessage>{};

            Bytes payload(rbuf.begin() + hdr + mask_len, rbuf.begin() + total);
            if (masked)
                for (std::size_t i = 0; i < payload.size(); ++i) payload[i] ^= rbuf[hdr + (i & 3)];
            rbuf.erase(rbuf.begin(), rbuf.begin() + total);

            if (opcode >= 8) {  // control frame
                if (!fin || payload.size() > 125) return fail("control frame tidak valid", ErrorCode::protocol);
                if (opcode == 9) {  // ping -> pong
                    (void)send_frame(10, payload);
                    continue;
                }
                if (opcode == 10) continue;  // pong
                if (opcode == 8) {
                    (void)send_frame(8, payload);
                    open = false;
                    return std::optional<WsMessage>{WsMessage{WsOp::close, std::move(payload)}};
                }
                return fail("opcode tidak dikenal", ErrorCode::protocol);
            }

            if (opcode == 1 || opcode == 2) {
                if (in_frag) return fail("fragmen WebSocket tidak berurutan", ErrorCode::protocol);
                frag_op = opcode == 1 ? WsOp::text : WsOp::binary;
                frag = std::move(payload);
                in_frag = !fin;
            } else if (opcode == 0) {
                if (!in_frag) return fail("continuation tanpa awal", ErrorCode::protocol);
                frag.insert(frag.end(), payload.begin(), payload.end());
                in_frag = !fin;
            } else {
                return fail("opcode tidak dikenal", ErrorCode::protocol);
            }
            if (frag.size() > kMaxMessage) return fail("pesan terlalu besar", ErrorCode::protocol);
            if (!in_frag) {
                WsMessage m{frag_op, std::move(frag)};
                frag.clear();
                return std::optional<WsMessage>{std::move(m)};
            }
        }
    }
};

WsClient::WsClient() : impl_(std::make_unique<Impl>()) {}
WsClient::~WsClient() = default;

bool WsClient::connected() const { return impl_ && impl_->open; }

Result<void> WsClient::connect(std::string_view url, const WsOptions& options) {
    auto parsed = parse_url(url);
    if (!parsed) return std::unexpected(parsed.error());
    const WsUrl& u = *parsed;

    std::signal(SIGPIPE, SIG_IGN);
    impl_ = std::make_unique<Impl>();
    Impl& s = *impl_;

    addrinfo hints{};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo* res = nullptr;
    const int rc = ::getaddrinfo(u.host.c_str(), u.port.c_str(), &hints, &res);
    if (rc != 0) return fail(std::string("getaddrinfo: ") + gai_strerror(rc), ErrorCode::io);
    std::unique_ptr<addrinfo, decltype(&::freeaddrinfo)> guard(res, &::freeaddrinfo);

    std::string last_err = "tidak ada alamat";
    for (addrinfo* p = res; p != nullptr; p = p->ai_next) {
        const int fd = ::socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (fd < 0) {
            last_err = std::strerror(errno);
            continue;
        }
        const int flags = ::fcntl(fd, F_GETFL, 0);
        ::fcntl(fd, F_SETFL, flags | O_NONBLOCK);
        int c = ::connect(fd, p->ai_addr, p->ai_addrlen);
        if (c < 0 && errno == EINPROGRESS) {
            pollfd pf{fd, POLLOUT, 0};
            const int pr = ::poll(&pf, 1, options.connect_timeout_ms);
            if (pr > 0) {
                int soerr = 0;
                socklen_t sl = sizeof soerr;
                ::getsockopt(fd, SOL_SOCKET, SO_ERROR, &soerr, &sl);
                c = soerr == 0 ? 0 : -1;
                errno = soerr;
            } else {
                c = -1;
                if (pr == 0) errno = ETIMEDOUT;
            }
        }
        if (c == 0) {
            ::fcntl(fd, F_SETFL, flags);
            s.fd = fd;
            break;
        }
        last_err = std::strerror(errno);
        ::close(fd);
    }
    if (s.fd < 0) return fail("gagal konek ke " + u.host + ": " + last_err, ErrorCode::io);
    const int one = 1;
    ::setsockopt(s.fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);

    if (u.tls) {
        s.ctx = SSL_CTX_new(TLS_client_method());
        if (!s.ctx) return fail("SSL_CTX_new gagal: " + ssl_error_string(), ErrorCode::io);
        SSL_CTX_set_min_proto_version(s.ctx, TLS1_2_VERSION);
        if (options.verify_tls) {
            SSL_CTX_set_default_verify_paths(s.ctx);
            SSL_CTX_set_verify(s.ctx, SSL_VERIFY_PEER, nullptr);
        }
        s.ssl = SSL_new(s.ctx);
        if (!s.ssl) return fail("SSL_new gagal", ErrorCode::io);
        SSL_set_fd(s.ssl, s.fd);
        SSL_set_tlsext_host_name(s.ssl, u.host.c_str());
        if (options.verify_tls) SSL_set1_host(s.ssl, u.host.c_str());
        if (SSL_connect(s.ssl) != 1) {
            const std::string why = ssl_error_string();
            s.teardown();
            return fail("TLS handshake gagal: " + why, ErrorCode::io);
        }
    }

    // --- HTTP upgrade ---
    const std::string key = base64_encode(crypto::random_bytes(16));
    const bool default_port = (u.tls && u.port == "443") || (!u.tls && u.port == "80");
    std::string req = std::format(
        "GET {} HTTP/1.1\r\nHost: {}{}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
        "Sec-WebSocket-Key: {}\r\nSec-WebSocket-Version: 13\r\n",
        u.path, u.host, default_port ? std::string() : ":" + u.port, key);
    for (const auto& [k, v] : options.headers) req += k + ": " + v + "\r\n";
    req += "\r\n";

    s.open = true;
    if (auto w = s.write_all(view_of(req)); !w) {
        s.teardown();
        return w;
    }

    static constexpr std::string_view kEnd = "\r\n\r\n";
    const auto start = Clock::now();
    std::size_t header_end = 0;
    for (;;) {
        const auto it = std::search(s.rbuf.begin(), s.rbuf.end(), kEnd.begin(), kEnd.end());
        if (it != s.rbuf.end()) {
            header_end = static_cast<std::size_t>(it - s.rbuf.begin()) + 4;
            break;
        }
        const int remaining = options.handshake_timeout_ms - elapsed_ms(start);
        if (remaining <= 0 || s.rbuf.size() > 65536) {
            s.teardown();
            return fail("handshake WebSocket timeout / header terlalu besar", ErrorCode::timeout);
        }
        std::uint8_t tmp[4096];
        auto n = s.read_some(tmp, sizeof tmp, remaining);
        if (!n) {
            s.teardown();
            return std::unexpected(n.error());
        }
        s.rbuf.insert(s.rbuf.end(), tmp, tmp + *n);
    }
    const std::string head(s.rbuf.begin(), s.rbuf.begin() + static_cast<std::ptrdiff_t>(header_end));
    s.rbuf.erase(s.rbuf.begin(), s.rbuf.begin() + static_cast<std::ptrdiff_t>(header_end));

    if (head.rfind("HTTP/1.1 101", 0) != 0) {
        const std::string line = head.substr(0, head.find("\r\n"));
        s.teardown();
        return fail("upgrade ditolak server: " + line, ErrorCode::protocol);
    }
    std::string lower = head;
    std::ranges::transform(lower, lower.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    const auto pos = lower.find("sec-websocket-accept:");
    if (pos == std::string::npos) {
        s.teardown();
        return fail("respons tanpa Sec-WebSocket-Accept", ErrorCode::protocol);
    }
    const auto eol = head.find("\r\n", pos);
    std::string got = head.substr(pos + 21, eol - pos - 21);
    while (!got.empty() && got.front() == ' ') got.erase(got.begin());
    while (!got.empty() && (got.back() == ' ' || got.back() == '\r')) got.pop_back();
    const std::string expected = base64_encode(crypto::sha1(view_of(key + std::string(kWsGuid))));
    if (got != expected) {
        s.teardown();
        return fail("Sec-WebSocket-Accept tidak cocok", ErrorCode::protocol);
    }
    logf(LogLevel::debug, "websocket terhubung ke {}", u.host);
    return {};
}

Result<void> WsClient::send_binary(ByteView data) { return impl_->send_frame(2, data); }
Result<void> WsClient::send_text(std::string_view text) { return impl_->send_frame(1, view_of(text)); }

Result<WsMessage> WsClient::receive(int timeout_ms) {
    Impl& s = *impl_;
    const auto start = Clock::now();
    for (;;) {
        auto parsed = s.try_parse();
        if (!parsed) return std::unexpected(parsed.error());
        if (*parsed) return std::move(**parsed);
        if (!s.open) return fail("koneksi tidak terbuka", ErrorCode::closed);
        int remaining = -1;
        if (timeout_ms >= 0) remaining = std::max(0, timeout_ms - elapsed_ms(start));
        std::uint8_t tmp[16384];
        auto n = s.read_some(tmp, sizeof tmp, remaining);
        if (!n) return std::unexpected(n.error());
        s.rbuf.insert(s.rbuf.end(), tmp, tmp + *n);
    }
}

void WsClient::close(std::uint16_t code) {
    if (!impl_ || !impl_->open) return;
    const Bytes payload{static_cast<std::uint8_t>(code >> 8), static_cast<std::uint8_t>(code & 0xFF)};
    (void)impl_->send_frame(8, payload);
    impl_->teardown();
}

}  // namespace wa
