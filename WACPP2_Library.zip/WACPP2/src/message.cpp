#include "wa/message.hpp"

namespace wa {
namespace {

std::string sub_string(ByteView msg, std::uint32_t field) {
    pb::Reader r(msg);
    for (;;) {
        auto f = r.next();
        if (!f || !*f) return {};
        if ((*f)->number == field && (*f)->wire == 2) return to_string((*f)->data);
    }
}

std::string protocol_kind(ByteView msg) {
    pb::Reader r(msg);
    for (;;) {
        auto f = r.next();
        if (!f || !*f) break;
        if ((*f)->number == 2 && (*f)->wire == 0) {
            switch ((*f)->value) {
                case 0: return "protocol:REVOKE";
                case 3: return "protocol:EPHEMERAL_SETTING";
                case 4: return "protocol:EPHEMERAL_SYNC_RESPONSE";
                case 5: return "protocol:HISTORY_SYNC_NOTIFICATION";
                case 6: return "protocol:APP_STATE_SYNC_KEY_SHARE";
                case 7: return "protocol:APP_STATE_SYNC_KEY_REQUEST";
                case 8: return "protocol:MSG_FANOUT_BACKFILL_REQUEST";
                case 9: return "protocol:INITIAL_SECURITY_NOTIFICATION_SETTING_SYNC";
                case 10: return "protocol:APP_STATE_FATAL_EXCEPTION_NOTIFICATION";
                case 11: return "protocol:SHARE_PHONE_NUMBER";
                case 14: return "protocol:MESSAGE_EDIT";
                default: return "protocol:" + std::to_string((*f)->value);
            }
        }
    }
    return "protocol";
}

void assign(IncomingMessage& m, std::string kind, std::string text) {
    if (!m.kind.empty()) return;  // konten pertama yang bermakna menang
    m.kind = std::move(kind);
    m.text = std::move(text);
}

void describe(ByteView data, IncomingMessage& m, int depth);

void describe_nested(ByteView wrapper, std::uint32_t field, IncomingMessage& m, int depth) {
    pb::Reader r(wrapper);
    for (;;) {
        auto f = r.next();
        if (!f || !*f) return;
        if ((*f)->number == field && (*f)->wire == 2) {
            describe((*f)->data, m, depth + 1);
            return;
        }
    }
}

void describe(ByteView data, IncomingMessage& m, int depth) {
    if (depth > 4) return;
    pb::Reader r(data);
    for (;;) {
        auto f = r.next();
        if (!f || !*f) return;
        const auto& fd = **f;
        if (fd.wire != 2) continue;
        switch (fd.number) {
            case 1: assign(m, "text", to_string(fd.data)); break;       // conversation
            case 2: m.has_sender_key = true; break;                     // senderKeyDistributionMessage
            case 3: assign(m, "image", sub_string(fd.data, 3)); break;  // caption
            case 4: assign(m, "contact", sub_string(fd.data, 1)); break;
            case 5: assign(m, "location", ""); break;
            case 6: assign(m, "text", sub_string(fd.data, 1)); break;   // extendedTextMessage.text
            case 7: assign(m, "document", sub_string(fd.data, 8)); break;  // fileName
            case 8: assign(m, "audio", ""); break;
            case 9: assign(m, "video", sub_string(fd.data, 7)); break;  // caption
            case 12: assign(m, protocol_kind(fd.data), ""); break;      // protocolMessage
            case 31: describe_nested(fd.data, 2, m, depth); break;      // deviceSentMessage.message
            case 37:
            case 40: describe_nested(fd.data, 1, m, depth); break;      // viewOnce / ephemeral
            case 46: assign(m, "reaction", sub_string(fd.data, 2)); break;
            default: break;
        }
    }
}

}  // namespace

Result<Bytes> unpad_random_max16(ByteView data) {
    if (data.empty()) return fail("pesan kosong", ErrorCode::protocol);
    const std::size_t pad = data.back();
    if (pad > data.size()) return fail("padding pesan tidak valid", ErrorCode::protocol);
    return Bytes(data.begin(), data.end() - static_cast<std::ptrdiff_t>(pad));
}

IncomingMessage parse_message(ByteView proto) {
    IncomingMessage m;
    m.raw.assign(proto.begin(), proto.end());
    describe(proto, m, 0);
    if (m.kind.empty()) m.kind = m.has_sender_key ? "sender-key" : "unknown";
    return m;
}

}  // namespace wa
