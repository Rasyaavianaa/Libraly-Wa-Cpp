#include "wa/payload.hpp"

#include <openssl/evp.h>

#include <charconv>

namespace wa {
namespace {

constexpr std::uint64_t kPlatformWeb = 14;
constexpr std::uint64_t kConnectWifiUnknown = 1;
constexpr std::uint64_t kReasonUserActivated = 1;
constexpr std::uint64_t kPlatformChrome = 1;  // DeviceProps.PlatformType.CHROME

Bytes md5(ByteView data) {
    Bytes out(EVP_MAX_MD_SIZE);
    unsigned int len = 0;
    EVP_Digest(data.data(), data.size(), out.data(), &len, EVP_md5(), nullptr);
    out.resize(len);
    return out;
}

Bytes be_bytes(std::uint32_t value, int width) {
    Bytes out(static_cast<std::size_t>(width));
    for (int i = 0; i < width; ++i)
        out[static_cast<std::size_t>(width - 1 - i)] = static_cast<std::uint8_t>(value >> (8 * i));
    return out;
}

pb::Writer user_agent(const WaVersion& v) {
    pb::Writer app;
    app.varint(1, v.primary).varint(2, v.secondary).varint(3, v.tertiary);
    pb::Writer ua;
    ua.varint(1, kPlatformWeb)
        .message(2, app)
        .string(3, "000")
        .string(4, "000")
        .string(5, "0.1")
        .string(7, "Desktop")
        .string(8, "0.1")
        .varint(10, 0)
        .string(11, "en")
        .string(12, "US");
    return ua;
}

void add_common(pb::Writer& p, const WaVersion& v) {
    p.message(5, user_agent(v));
    pb::Writer web;
    web.varint(4, 0);  // WEB_BROWSER
    p.message(6, web);
    p.varint(12, kConnectWifiUnknown);
    p.varint(13, kReasonUserActivated);
}

Bytes device_props(std::string_view os) {
    pb::Writer ver;
    ver.varint(1, 10).varint(2, 15).varint(3, 7);
    pb::Writer p;
    p.string(1, os).message(2, ver).varint(3, kPlatformChrome).varint(4, 0);
    return p.take();
}

Result<std::uint64_t> parse_u64(std::string_view s) {
    std::uint64_t v = 0;
    const auto [p, ec] = std::from_chars(s.data(), s.data() + s.size(), v);
    if (s.empty() || ec != std::errc{} || p != s.data() + s.size()) return fail("angka tidak valid: " + std::string(s));
    return v;
}

}  // namespace

Result<WaVersion> parse_version(std::string_view text) {
    std::string s(text);
    std::ranges::replace(s, ',', '.');
    std::vector<std::uint32_t> parts;
    std::size_t pos = 0;
    while (pos <= s.size()) {
        const auto dot = s.find('.', pos);
        const std::string part = s.substr(pos, dot == std::string::npos ? std::string::npos : dot - pos);
        std::uint32_t x = 0;
        const auto [p, ec] = std::from_chars(part.data(), part.data() + part.size(), x);
        if (part.empty() || ec != std::errc{} || p != part.data() + part.size())
            return fail("versi tidak valid, contoh: 2.3000.1015901307");
        parts.push_back(x);
        if (dot == std::string::npos) break;
        pos = dot + 1;
    }
    if (parts.size() != 3) return fail("versi harus 3 bagian, contoh: 2.3000.1015901307");
    return WaVersion{parts[0], parts[1], parts[2]};
}

Result<Bytes> build_registration_payload(const Creds& c, const WaVersion& v, std::string_view os) {
    if (c.identity_key.pub.size() != 32 || c.signed_prekey.pub.size() != 32 || c.signed_prekey_sig.size() != 64)
        return fail("creds belum lengkap untuk registrasi", ErrorCode::crypto);

    const std::string version_text = std::format("{}.{}.{}", v.primary, v.secondary, v.tertiary);
    pb::Writer pairing;
    pairing.bytes(1, be_bytes(c.registration_id, 4))
        .bytes(2, Bytes{5})
        .bytes(3, c.identity_key.pub)
        .bytes(4, be_bytes(c.signed_prekey_id, 3))
        .bytes(5, c.signed_prekey.pub)
        .bytes(6, c.signed_prekey_sig)
        .bytes(7, md5(view_of(version_text)))
        .bytes(8, device_props(os));

    pb::Writer p;
    p.varint(3, 0);  // passive = false
    add_common(p, v);
    p.message(19, pairing).varint(33, 0);  // pull = false
    return p.take();
}

Result<Bytes> build_login_payload(const Creds& c, const WaVersion& v) {
    const auto at = c.me_jid.find('@');
    if (c.me_jid.empty() || at == std::string::npos) return fail("login: me_jid kosong/tidak valid", ErrorCode::protocol);
    std::string user = c.me_jid.substr(0, at);
    std::uint64_t device = 0;
    if (const auto colon = user.find(':'); colon != std::string::npos) {
        auto d = parse_u64(std::string_view(user).substr(colon + 1));
        if (!d) return std::unexpected(d.error());
        device = *d;
        user.resize(colon);
    }
    if (const auto us = user.find('_'); us != std::string::npos) user.resize(us);
    auto number = parse_u64(user);
    if (!number) return std::unexpected(number.error());

    pb::Writer p;
    p.varint(1, *number).varint(3, 1);  // username, passive = true
    add_common(p, v);
    p.varint(18, device).varint(33, 1);  // device, pull = true
    return p.take();
}

}  // namespace wa
