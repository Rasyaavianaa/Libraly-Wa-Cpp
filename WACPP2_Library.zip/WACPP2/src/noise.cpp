#include "wa/noise.hpp"

namespace wa {
namespace {

constexpr std::string_view kNoiseMode = std::string_view("Noise_XX_25519_AESGCM_SHA256\0\0\0\0", 32);

Bytes wa_header() { return Bytes{'W', 'A', kWaMagic, kWaDictVersion}; }

Bytes build_intro(ByteView routing) {
    Bytes header = wa_header();
    if (routing.empty()) return header;
    Bytes out{'E', 'D', 0, 1};
    out.push_back(static_cast<std::uint8_t>(routing.size() >> 16));
    out.push_back(static_cast<std::uint8_t>((routing.size() >> 8) & 0xFF));
    out.push_back(static_cast<std::uint8_t>(routing.size() & 0xFF));
    out.insert(out.end(), routing.begin(), routing.end());
    out.insert(out.end(), header.begin(), header.end());
    return out;
}

}  // namespace

NoiseSession::NoiseSession(crypto::KeyPair ephemeral, Bytes routing_info)
    : ephemeral_(std::move(ephemeral)), intro_(build_intro(routing_info)) {
    const Bytes mode = to_bytes(kNoiseMode);
    hash_ = mode.size() == 32 ? mode : crypto::sha256(mode);
    salt_ = hash_;
    enc_key_ = hash_;
    dec_key_ = hash_;
    authenticate(wa_header());
    authenticate(ephemeral_.pub);
}

Bytes NoiseSession::make_iv(std::uint32_t counter) {
    Bytes iv(12, 0);
    iv[8] = static_cast<std::uint8_t>(counter >> 24);
    iv[9] = static_cast<std::uint8_t>(counter >> 16);
    iv[10] = static_cast<std::uint8_t>(counter >> 8);
    iv[11] = static_cast<std::uint8_t>(counter);
    return iv;
}

void NoiseSession::authenticate(ByteView data) {
    if (finished_) return;
    hash_ = crypto::sha256(concat({hash_, data}));
}

void NoiseSession::mix_into_key(ByteView data) {
    const Bytes out = crypto::hkdf_sha256(data, 64, salt_);
    salt_.assign(out.begin(), out.begin() + 32);
    enc_key_.assign(out.begin() + 32, out.end());
    dec_key_ = enc_key_;
    read_counter_ = 0;
    write_counter_ = 0;
}

Result<Bytes> NoiseSession::encrypt(ByteView plaintext) {
    auto ct = crypto::aes256_gcm_encrypt(enc_key_, make_iv(write_counter_), plaintext, hash_);
    if (!ct) return ct;
    ++write_counter_;
    authenticate(*ct);
    return ct;
}

Result<Bytes> NoiseSession::decrypt(ByteView ciphertext) {
    // Selama handshake satu counter dipakai bersama; setelah selesai counter baca/tulis terpisah.
    const std::uint32_t counter = finished_ ? read_counter_ : write_counter_;
    auto pt = crypto::aes256_gcm_decrypt(dec_key_, make_iv(counter), ciphertext, hash_);
    if (!pt) return pt;
    if (finished_) ++read_counter_;
    else ++write_counter_;
    authenticate(ciphertext);
    return pt;
}

Bytes NoiseSession::client_hello() const {
    pb::Writer hello;
    hello.bytes(1, ephemeral_.pub);
    pb::Writer msg;
    msg.message(2, hello);
    return msg.take();
}

Bytes NoiseSession::client_finish(ByteView key_enc, ByteView payload_enc) {
    pb::Writer fin;
    fin.bytes(1, key_enc).bytes(2, payload_enc);
    pb::Writer msg;
    msg.message(4, fin);
    return msg.take();
}

Result<ServerHello> NoiseSession::parse_server_hello(ByteView message) {
    pb::Reader outer(message);
    std::optional<ByteView> hello_bytes;
    for (;;) {
        auto f = outer.next();
        if (!f) return std::unexpected(f.error());
        if (!*f) break;
        if ((*f)->number == 3 && (*f)->wire == 2) hello_bytes = (*f)->data;
    }
    if (!hello_bytes) return fail("handshake: serverHello tidak ada", ErrorCode::protocol);

    ServerHello hello;
    pb::Reader inner(*hello_bytes);
    for (;;) {
        auto f = inner.next();
        if (!f) return std::unexpected(f.error());
        if (!*f) break;
        const auto& field = **f;
        if (field.wire != 2) continue;
        switch (field.number) {
            case 1: hello.ephemeral.assign(field.data.begin(), field.data.end()); break;
            case 2: hello.static_enc.assign(field.data.begin(), field.data.end()); break;
            case 3: hello.payload_enc.assign(field.data.begin(), field.data.end()); break;
            default: break;
        }
    }
    if (hello.ephemeral.size() != 32 || hello.static_enc.empty() || hello.payload_enc.empty())
        return fail("handshake: serverHello tidak lengkap", ErrorCode::protocol);
    return hello;
}

Result<Bytes> NoiseSession::process_server_hello(const ServerHello& hello, const crypto::KeyPair& noise_key) {
    authenticate(hello.ephemeral);

    auto dh1 = crypto::x25519_shared(ephemeral_.priv, hello.ephemeral);
    if (!dh1) return std::unexpected(dh1.error());
    mix_into_key(*dh1);

    auto server_static = decrypt(hello.static_enc);
    if (!server_static) return std::unexpected(server_static.error());
    server_static_ = std::move(*server_static);

    auto dh2 = crypto::x25519_shared(ephemeral_.priv, server_static_);
    if (!dh2) return std::unexpected(dh2.error());
    mix_into_key(*dh2);

    auto cert = decrypt(hello.payload_enc);
    if (!cert) return std::unexpected(cert.error());
    server_cert_ = std::move(*cert);

    auto key_enc = encrypt(noise_key.pub);
    if (!key_enc) return key_enc;

    auto dh3 = crypto::x25519_shared(noise_key.priv, hello.ephemeral);
    if (!dh3) return std::unexpected(dh3.error());
    mix_into_key(*dh3);
    return key_enc;
}

void NoiseSession::finish() {
    const Bytes out = crypto::hkdf_sha256(ByteView{}, 64, salt_);
    enc_key_.assign(out.begin(), out.begin() + 32);
    dec_key_.assign(out.begin() + 32, out.end());
    hash_.clear();
    read_counter_ = 0;
    write_counter_ = 0;
    finished_ = true;
}

Result<Bytes> NoiseSession::frame(ByteView payload) {
    Bytes data;
    if (finished_) {
        auto enc = encrypt(payload);
        if (!enc) return enc;
        data = std::move(*enc);
    } else {
        data.assign(payload.begin(), payload.end());
    }
    if (data.size() >= (std::size_t{1} << 24)) return fail("frame melebihi 16 MiB", ErrorCode::protocol);

    Bytes out;
    if (!sent_intro_) {
        out = intro_;
        sent_intro_ = true;
    }
    out.push_back(static_cast<std::uint8_t>(data.size() >> 16));
    out.push_back(static_cast<std::uint8_t>((data.size() >> 8) & 0xFF));
    out.push_back(static_cast<std::uint8_t>(data.size() & 0xFF));
    out.insert(out.end(), data.begin(), data.end());
    return out;
}

Result<std::vector<Bytes>> NoiseSession::unframe(ByteView incoming) {
    inbound_.insert(inbound_.end(), incoming.begin(), incoming.end());
    std::vector<Bytes> frames;
    for (;;) {
        if (inbound_.size() < 3) break;
        const std::size_t size = (std::size_t(inbound_[0]) << 16) | (std::size_t(inbound_[1]) << 8) | inbound_[2];
        if (inbound_.size() < 3 + size) break;
        Bytes chunk(inbound_.begin() + 3, inbound_.begin() + 3 + static_cast<std::ptrdiff_t>(size));
        inbound_.erase(inbound_.begin(), inbound_.begin() + 3 + static_cast<std::ptrdiff_t>(size));
        if (finished_) {
            auto plain = decrypt(chunk);
            if (!plain) return std::unexpected(plain.error());
            frames.push_back(std::move(*plain));
        } else {
            frames.push_back(std::move(chunk));
        }
    }
    return frames;
}

}  // namespace wa
