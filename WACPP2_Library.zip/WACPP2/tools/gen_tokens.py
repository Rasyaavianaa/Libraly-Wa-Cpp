#!/usr/bin/env python3
"""Hasilkan include/wa/tokens.inc dari constants.ts milik Baileys (tabel token WABinary)."""
import os
import sys
import urllib.request

URLS = [
    "https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/WABinary/constants.ts",
    "https://raw.githubusercontent.com/WhiskeySockets/Baileys/main/src/WABinary/constants.ts",
]
OUT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "..", "include", "wa", "tokens.inc"))


def load_source(arg):
    if arg and not arg.startswith("http"):
        with open(arg, "r", encoding="utf-8") as f:
            return f.read()
    urls = [arg] if arg else URLS
    last = None
    for url in urls:
        try:
            with urllib.request.urlopen(url, timeout=30) as r:
                return r.read().decode("utf-8")
        except Exception as e:  # noqa
            last = e
    sys.exit("gagal mengunduh constants.ts: %s\n"
             "unduh manual lalu jalankan: python3 tools/gen_tokens.py /path/constants.ts" % last)


def tokenize(src):
    toks = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c.isspace():
            i += 1
        elif src.startswith("//", i):
            j = src.find("\n", i)
            i = n if j < 0 else j + 1
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2)
            i = n if j < 0 else j + 2
        elif c in "'\"`":
            q = c
            i += 1
            buf = []
            while i < n and src[i] != q:
                if src[i] == "\\" and i + 1 < n:
                    e = src[i + 1]
                    if e == "n":
                        buf.append("\n"); i += 2
                    elif e == "t":
                        buf.append("\t"); i += 2
                    elif e == "u":
                        buf.append(chr(int(src[i + 2:i + 6], 16))); i += 6
                    elif e == "x":
                        buf.append(chr(int(src[i + 2:i + 4], 16))); i += 4
                    else:
                        buf.append(e); i += 2
                else:
                    buf.append(src[i]); i += 1
            i += 1
            toks.append(("s", "".join(buf)))
        elif c.isalpha() or c in "_$":
            j = i
            while j < n and (src[j].isalnum() or src[j] in "_$"):
                j += 1
            toks.append(("i", src[i:j]))
            i = j
        else:
            toks.append(("p", c))
            i += 1
    return toks


def parse_array(toks, i):
    items = []
    i += 1
    while i < len(toks):
        t = toks[i]
        if t == ("p", "["):
            sub, i = parse_array(toks, i)
            items.append(sub)
        elif t == ("p", "]"):
            return items, i + 1
        elif t[0] == "s":
            items.append(t[1])
            i += 1
        else:
            i += 1
    return items, i


def find_array(toks, name):
    for idx, t in enumerate(toks):
        if t != ("i", name):
            continue
        for j in range(idx + 1, min(idx + 14, len(toks))):
            if toks[j] == ("p", "="):
                if j + 1 < len(toks) and toks[j + 1] == ("p", "["):
                    arr, _ = parse_array(toks, j + 1)
                    return arr
                break
    return None


def cstr(s):
    out = ['"']
    for b in s.encode("utf-8"):
        ch = chr(b)
        if ch in '"\\':
            out.append("\\" + ch)
        elif 32 <= b < 127 and ch != "?":
            out.append(ch)
        else:
            out.append("\\%03o" % b)
    out.append('"')
    return "".join(out)


def main():
    src = load_source(sys.argv[1] if len(sys.argv) > 1 else None)
    toks = tokenize(src)
    single = find_array(toks, "SINGLE_BYTE_TOKENS")
    double = find_array(toks, "DOUBLE_BYTE_TOKENS")
    ok = (single and double and len(double) == 4
          and all(isinstance(x, str) for x in single)
          and all(isinstance(d, list) and d and all(isinstance(x, str) for x in d) for d in double))
    if not ok:
        sys.exit("format constants.ts tidak dikenali (single=%s double=%s). "
                 "tempel isi sekitar SINGLE_BYTE_TOKENS / DOUBLE_BYTE_TOKENS ke chat."
                 % (None if not single else len(single),
                    None if not double else [len(d) if isinstance(d, list) else "?" for d in double]))

    lines = ["// Dihasilkan oleh tools/gen_tokens.py - jangan diedit manual.",
             "namespace wa::binary::tokens {", ""]

    def emit(name, items):
        lines.append("inline constexpr const char* %s[] = {" % name)
        for it in items:
            lines.append("    %s," % cstr(it))
        lines.append("};")
        lines.append("")

    emit("kSingle", single)
    for i, d in enumerate(double):
        emit("kDouble%d" % i, d)
    lines.append("}  // namespace wa::binary::tokens")

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("single=%d double=%s -> %s" % (len(single), [len(d) for d in double], OUT))


if __name__ == "__main__":
    main()
