#pragma once

#include "wa/common.hpp"

namespace wa::crypto {

// Tanda tangan XEdDSA (setara curve25519_sign milik libsignal) memakai kunci X25519.
Result<Bytes> xeddsa_sign(ByteView x25519_priv, ByteView message);
bool xeddsa_verify(ByteView x25519_pub, ByteView message, ByteView signature);

}  // namespace wa::crypto
