#pragma once

#include <string>

#include "wa/common.hpp"

namespace wa {

struct IncomingMessage {
    std::string id;
    std::string from;      // chat (JID pengirim 1:1 atau grup)
    std::string sender_pn; // nomor asli pengirim dari WhatsApp
    std::string author;    // pengirim sebenarnya
    std::string category;  // mis. "peer" untuk sinkronisasi antar-perangkat sendiri
    std::uint64_t timestamp{0};
    std::string kind;      // text, image, video, document, protocol:..., dll.
    std::string text;      // isi teks / caption bila ada
    bool has_sender_key{false};
    Bytes raw;             // protobuf Message mentah (setelah unpad)
};

// Membuang padding acak WhatsApp (byte terakhir = jumlah padding).
Result<Bytes> unpad_random_max16(ByteView data);
// Membaca protobuf Message dan mengisi kind/text.
IncomingMessage parse_message(ByteView proto);

}  // namespace wa
