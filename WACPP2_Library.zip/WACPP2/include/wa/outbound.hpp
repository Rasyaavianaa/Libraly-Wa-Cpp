#pragma once

#include <optional>
#include <string>
#include <string_view>
#include <vector>

#include "wa/binary.hpp"
#include "wa/common.hpp"
#include "wa/creds.hpp"
#include "wa/signal.hpp"

namespace wa::outbound {

struct JidParts {
    std::string user;
    std::string server;
    std::uint32_t device{0};
};

struct Participant {
    std::string jid;  // JID perangkat tujuan
    sig::Encrypted enc;
};

std::optional<JidParts> split_jid(std::string_view jid);
std::string format_jid(const JidParts& parts);          // user[:device]@server
std::string normalize_jid(std::string_view input);      // "+62 857-..." -> "62857...@s.whatsapp.net"
std::string generate_message_id();                      // "3EB0" + 36 hex

Bytes build_text_message(std::string_view text);                                  // proto Message{conversation}
Bytes build_device_sent_message(std::string_view destination_jid, ByteView message);  // Message{deviceSentMessage}
Bytes pad_random_max16(ByteView data);                                            // padding acak 1..15

binary::Node build_usync_devices_query(const std::vector<std::string>& user_jids, std::string_view iq_id,
                                       std::string_view sid);
Result<std::vector<std::string>> parse_usync_devices(const binary::Node& iq);

binary::Node build_key_fetch_query(const std::vector<std::string>& jids, std::string_view iq_id);
Result<std::vector<sig::PreKeyBundle>> parse_key_bundles(const binary::Node& iq);

binary::Node build_message_stanza(std::string_view to, std::string_view id, std::string_view type,
                                  const std::vector<Participant>& participants, const Creds& creds);

}  // namespace wa::outbound
