#pragma once

#include "wa/common.hpp"
#include "wa/crypto.hpp"

namespace wa {

inline constexpr std::uint8_t kWaMagic = 6;
inline constexpr std::uint8_t kWaDictVersion = 3;

struct ServerHello {
    Bytes ephemeral;    // 32 byte
    Bytes static_enc;   // 32 + 16 tag
    Bytes payload_enc;  // rantai sertifikat terenkripsi
};

// Noise_XX_25519_AESGCM_SHA256 sesuai transport WhatsApp Web (multi-device).
class NoiseSession {
public:
    explicit NoiseSession(crypto::KeyPair ephemeral, Bytes routing_info = {});

    // HandshakeMessage{clientHello{ephemeral}} (belum dibingkai).
    [[nodiscard]] Bytes client_hello() const;
    [[nodiscard]] static Result<ServerHello> parse_server_hello(ByteView handshake_message);
    // HandshakeMessage{clientFinish{static, payload}} (belum dibingkai).
    [[nodiscard]] static Bytes client_finish(ByteView key_enc, ByteView payload_enc);

    // Memproses ServerHello; hasilnya noise public key terenkripsi (field "static" clientFinish).
    [[nodiscard]] Result<Bytes> process_server_hello(const ServerHello& hello, const crypto::KeyPair& noise_key);

    [[nodiscard]] Result<Bytes> encrypt(ByteView plaintext);
    [[nodiscard]] Result<Bytes> decrypt(ByteView ciphertext);

    // Dipanggil setelah clientFinish terkirim.
    void finish();
    [[nodiscard]] bool finished() const noexcept { return finished_; }

    // Bingkai keluar: [intro header sekali] + len(3 byte) + (terenkripsi bila handshake selesai).
    [[nodiscard]] Result<Bytes> frame(ByteView payload);
    // Bingkai masuk: memecah buffer menjadi frame (didekripsi bila handshake selesai).
    [[nodiscard]] Result<std::vector<Bytes>> unframe(ByteView incoming);

    [[nodiscard]] const Bytes& server_static() const noexcept { return server_static_; }
    [[nodiscard]] const Bytes& server_cert() const noexcept { return server_cert_; }

private:
    void authenticate(ByteView data);
    void mix_into_key(ByteView data);
    [[nodiscard]] static Bytes make_iv(std::uint32_t counter);

    crypto::KeyPair ephemeral_;
    Bytes intro_;
    Bytes hash_;
    Bytes salt_;
    Bytes enc_key_;
    Bytes dec_key_;
    Bytes server_static_;
    Bytes server_cert_;
    Bytes inbound_;
    std::uint32_t read_counter_{0};
    std::uint32_t write_counter_{0};
    bool finished_{false};
    bool sent_intro_{false};
};

}  // namespace wa
