#pragma once

#include <chrono>
#include <deque>
#include <utility>
#include <vector>
#include <functional>
#include <map>
#include <mutex>
#include <string>

#include "wa/common.hpp"
#include "wa/creds.hpp"
#include "wa/message.hpp"
#include "wa/outbound.hpp"
#include "wa/payload.hpp"
#include "wa/signal.hpp"

namespace wa {

class Client;

struct ClientConfig {
    std::string url = "wss://web.whatsapp.com/ws/chat";
    std::string creds_path = "creds.txt";
    std::string store_path = "signal.txt";
    std::string phone;        // nomor internasional tanpa '+', wajib untuk pairing pertama
    std::string custom_code;  // opsional: 8 karakter Crockford
    WaVersion version;
    std::string browser_os = "Ubuntu";
    std::string browser_name = "Chrome";
    int max_restarts = 5;
    bool stay_online = false;      // false: berhenti begitu login sukses
    bool exit_after_send = false;  // berhenti setelah semua pesan keluar di-ack server
    bool lifetime_mode = false;    // retry koneksi tanpa batas dengan exponential backoff
    std::size_t prekey_batch = 100;
    std::size_t prekey_min = 10;
    std::function<void(std::string_view)> on_pairing_code;
    std::function<void(const IncomingMessage&)> on_message;
    std::function<void(Client&)> on_ready;  // dipanggil sekali setelah login berhasil (mode stay_online)
};

class Client {
public:
    explicit Client(ClientConfig config);

    // Blocking: pairing (bila belum terdaftar) -> restart -> login -> kirim/terima pesan.
    Result<void> run();

    // Aman dipanggil dari thread/callback mana pun; dikirim oleh event loop.
    void enqueue_text(std::string to, std::string text);

    [[nodiscard]] const Creds& creds() const noexcept { return creds_; }

private:
    struct OutgoingText {
        std::string to;
        std::string text;
    };
    enum class End { restart, logged_in, closed };

    Result<End> session();
    std::string next_id();
    bool pop_outbox(OutgoingText& item);
    bool outbox_empty();

    ClientConfig cfg_;
    sig::Store store_;
    Creds creds_;
    std::map<std::string, int> retries_;
    std::mutex outbox_mutex_;
    std::deque<OutgoingText> outbox_;
    std::uint32_t id_a_{0};
    std::uint32_t id_b_{0};
    std::uint32_t counter_{0};
    std::map<std::string, std::pair<std::chrono::steady_clock::time_point, std::vector<std::string>>> device_cache_;
};

}  // namespace wa
