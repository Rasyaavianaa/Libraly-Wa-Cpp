# WACPP2 — lifetime runtime + `cpp` command prefix

WACPP2 is an additive working copy of the supplied WACPP project. Existing WhatsApp transport, Noise handshake, pairing, encryption, text-send, and receipt code paths have not been intentionally rewritten. The original `pair` command remains available.

## What's added

- `cpp start`: starts the existing online event loop and enables lifetime reconnect mode.
- Capped exponential reconnect delay: 2, 4, 8, 16, 32, then 60 seconds between retry attempts.
- Private-chat command prefix `cpp` (case-insensitive):
  - `cpp menu`
  - `cpp ping`
  - `cpp status`
  - `cpp about`
- New executable target: `build/wacpp2`. The previously supplied `build/wa_demo` binary is retained in the archive.

## Build in Termux

The object files supplied in `build/` are Android/Termux artifacts. Build this updated source on the Android device in Termux:

```bash
pkg update
pkg install clang make openssl libsodium zlib python
make -j2
```

The executable produced by the updated Makefile is `build/wacpp2`.

## Start the lifetime runtime

Use the same WhatsApp Web version string that was already working with this WACPP copy:

```bash
./build/wacpp2 cpp start --version 2.3000.REV
```

Replace `2.3000.REV` with the exact version string from your successful previous command. If this is a fresh, unpaired credentials file, add `--phone 628xxxxxxxxxx` for the first pairing. Existing registered `creds.txt` and `signal.txt` are used by default.

Stop the foreground process with `Ctrl+C`.

## Test the bot

From a **private WhatsApp chat** with the linked account, send:

```text
cpp menu
```

Then try `cpp ping`, `cpp status`, or `cpp about`.

This first command handler intentionally replies only in private chats. Group-message fan-out has not been implemented in this WACPP snapshot, so group commands are logged and not sent. Media, rich interactive messages, and game features are not part of this runtime increment yet.

## Android background note

Lifetime mode keeps the C++ process and session loop running and retries transient connection failures. It cannot guarantee Android will never kill Termux in the background. For longer foreground/background operation, disable battery optimization for Termux. If Termux:API is installed, `termux-wake-lock` can help hold a CPU wakelock; release it with `termux-wake-unlock` when stopping.

## Session-data safety

`creds.txt` and `signal.txt` contain account/session cryptographic material. Keep this ZIP private and do not post it publicly or send it to anyone else. Back them up securely before replacing the working project.
